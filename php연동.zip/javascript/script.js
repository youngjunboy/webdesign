$('.navi li').mouseover(function(){
    $('.submenu').stop().slideDown(300)
    $('.subimg').stop().slideDown(300)
});

$('.navi li').mouseout(function(){
    $('.submenu').stop().slideUp(300)
    $('.subimg').stop().slideUp(300)
});

setInterval(function(){
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft:-1200});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft:-2400});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft:0});
    $('.slidelist').delay(2000);
})
