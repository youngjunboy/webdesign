jQuery(document).ready(function(){
    $('.navi>li').mouseover(function(){
        $('.submenu').stop().slideDown(500)
    });

    $('.navi>li').mouseout(function(){
        $('.submenu').stop().slideUp(500)
    });

    $('.notice li').click(function(){
        $('#modal').addClass('active')
    })
    $('.btn').click(function(){
        $('#modal').removeClass('active')
    })

    $('.tabmenu>li>a').click(function(){
        $(this).parent().addClass('active')
        .siblings().removeClass('active')
        return false;
    })
});

